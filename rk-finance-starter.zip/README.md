# RK Finance — starter codebase

A backend + frontend scaffold for an RBI-compliant NBFC/lending platform.
This is a starting structure, not a finished product — payment gateway,
e-KYC/CKYC, and OTP/SMS integrations are left as placeholders for approved
providers you select.

## What's included

```
backend/
  src/
    server.js              Express app entry point (helmet, CORS, rate limiting, audit logging)
    routes/                 auth, loans, emi, applications, admin, compliance
    controllers/             auth + application business logic
    models/                  Customer, LoanProduct, LoanApplication, AuditLog (Mongoose)
    middleware/               JWT auth + role-based access control, audit logger
    utils/                    EMI calculation (reducing balance method)
  .env.example

frontend/
  src/
    App.jsx                 React Router skeleton
    pages/                   Home, LoanProducts, LoanDetail, Calculator, Apply, Login, Compliance
    components/EmiCalculator.jsx
    utils/apiClient.js       axios wrapper with JWT attached to requests

rk-finance-prototype.html  Standalone interactive design prototype (open directly in a browser)
```

## Getting started

```bash
cd backend
cp .env.example .env      # fill in JWT_SECRET, MONGO_URI, provider keys
npm install
npm run dev                # http://localhost:4000

cd ../frontend
npm install
npm run dev                 # http://localhost:5173
```

The frontend page components are currently placeholders. Each one has a
comment pointing to the matching section in `rk-finance-prototype.html` —
port the markup and EMI logic from there into `pages/*.jsx`, replacing the
prototype's hardcoded loan array with a call to `GET /api/loans`.

## Things you must plug in before this is production-ready

| Area | What's stubbed | What you need |
|---|---|---|
| OTP / SMS | Console-logged OTP in dev | An approved provider (e.g. MSG91, Twilio Verify) |
| e-KYC / CKYC | Storage reference field only | An approved e-KYC/CKYC provider integration |
| Payments | Not implemented | A licensed payment gateway (UPI/cards/net banking/BBPS) |
| Document storage | `storageRef` string only | Encrypted object storage (S3/Azure Blob/GCS) with access controls |
| KFS generation | Fields defined on the application model | A PDF generation step, triggered before disbursement |

## Where RBI compliance requirements map to code

- **Transparent rate/fee disclosure** — `LoanProduct` model fields, rendered on `/loans/:slug`.
- **Key Fact Statement before disbursement** — `LoanApplication.keyFactStatement`, must be shown and accepted before `status` moves to `approved`.
- **Explicit, timestamped consent** — `Customer.consents[]` at registration, `LoanApplication.consentTimestamp` at application; both logged via `recordAuditEvent`.
- **Grievance redressal** — `GET /api/compliance/disclosures` serves the grievance officer contact and escalation window; wire this into the Compliance page.
- **Audit trail for admin actions** — every admin route in `admin.routes.js` calls `recordAuditEvent`; `AuditLog` is intended to be append-only.
- **Statutory identifiers (RBI reg. no., CIN, GSTIN)** — read from environment variables so they're not hardcoded, and stay `null`/unconfirmed until the business owner fills them in.

## Do not do this until you've confirmed with counsel and your compliance function

- Display "RBI approved" or "RBI licensed" anywhere until a valid Certificate of Registration is on file — the `isRegistrationConfirmed` flag in `/api/compliance/disclosures` is `false` by default for this reason.
- Store raw Aadhaar numbers, full account numbers, or unencrypted KYC documents — the schema intentionally stores references/tokens, not raw values.
- Go live on payments or e-KYC without a licensed provider agreement in place.

This scaffold covers the RBI-facing plumbing (disclosures, consent, audit
trail, KFS fields) but does not replace legal or compliance sign-off before
launch.
