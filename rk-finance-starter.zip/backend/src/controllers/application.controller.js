const LoanApplication = require('../models/LoanApplication.model');
const LoanProduct = require('../models/LoanProduct.model');
const { recordAuditEvent } = require('../middleware/audit.middleware');

async function createApplication(req, res) {
  try {
    const { loanProductSlug, loanAmountRequested, loanPurpose, tenureMonthsRequested } = req.body;

    const loanProduct = await LoanProduct.findOne({ slug: loanProductSlug, isActive: true });
    if (!loanProduct) return res.status(404).json({ error: 'Loan product not found.' });

    const application = await LoanApplication.create({
      customer: req.user.id,
      loanProduct: loanProduct._id,
      loanAmountRequested,
      loanPurpose,
      tenureMonthsRequested,
    });

    await recordAuditEvent({
      actorId: req.user.id,
      actorType: 'customer',
      action: 'LOAN_APPLICATION_CREATED',
      targetId: application._id,
    });

    res.status(201).json(application);
  } catch (err) {
    res.status(500).json({ error: 'Could not create application.' });
  }
}

async function listMyApplications(req, res) {
  const applications = await LoanApplication.find({ customer: req.user.id }).populate('loanProduct');
  res.json(applications);
}

async function getApplication(req, res) {
  const application = await LoanApplication.findOne({ _id: req.params.id, customer: req.user.id }).populate('loanProduct');
  if (!application) return res.status(404).json({ error: 'Application not found.' });
  res.json(application);
}

// Document upload here should only ever receive a pre-signed storage reference
// from an encrypted bucket - never accept raw file bytes directly into the API layer
// without virus scanning and encryption at rest.
async function attachDocument(req, res) {
  const { type, storageRef } = req.body;
  const application = await LoanApplication.findOne({ _id: req.params.id, customer: req.user.id });
  if (!application) return res.status(404).json({ error: 'Application not found.' });

  application.documents.push({ type, storageRef });
  await application.save();

  await recordAuditEvent({
    actorId: req.user.id,
    actorType: 'customer',
    action: 'DOCUMENT_UPLOADED',
    targetId: application._id,
    metadata: { type },
  });

  res.json(application);
}

// Records the customer's explicit, timestamped consent to the loan agreement / KFS,
// as required before disbursement under RBI's disclosure norms.
async function recordConsent(req, res) {
  const application = await LoanApplication.findOne({ _id: req.params.id, customer: req.user.id });
  if (!application) return res.status(404).json({ error: 'Application not found.' });

  application.consentTimestamp = new Date();
  await application.save();

  await recordAuditEvent({
    actorId: req.user.id,
    actorType: 'customer',
    action: 'CONSENT_ACCEPTED',
    targetId: application._id,
    metadata: { ip: req.ip },
  });

  res.json({ consentTimestamp: application.consentTimestamp });
}

module.exports = { createApplication, listMyApplications, getApplication, attachDocument, recordConsent };
