const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Customer = require('../models/Customer.model');
const { recordAuditEvent } = require('../middleware/audit.middleware');

// In-memory OTP store for prototype purposes only.
// Replace with Redis (with a short TTL) before going to production.
const otpStore = new Map();

function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

async function sendOtp(req, res) {
  const { mobileNumber } = req.body;
  if (!mobileNumber) return res.status(400).json({ error: 'Mobile number is required.' });

  const otp = generateOtp();
  otpStore.set(mobileNumber, { otp, expiresAt: Date.now() + 5 * 60 * 1000 });

  // TODO: integrate an approved OTP/SMS provider here (e.g. MSG91, Twilio Verify).
  // Never log or return the OTP itself outside of local development.
  if (process.env.NODE_ENV !== 'production') {
    console.log(`[dev only] OTP for ${mobileNumber}: ${otp}`);
  }

  res.json({ message: 'OTP sent.' });
}

async function verifyOtp(req, res) {
  const { mobileNumber, otp } = req.body;
  const record = otpStore.get(mobileNumber);

  if (!record || record.expiresAt < Date.now()) {
    return res.status(400).json({ error: 'OTP expired or not found. Request a new one.' });
  }
  if (record.otp !== otp) {
    return res.status(400).json({ error: 'Incorrect OTP.' });
  }

  otpStore.delete(mobileNumber);
  res.json({ verified: true });
}

async function register(req, res) {
  try {
    const { fullName, mobileNumber, email, password, consents } = req.body;
    if (!fullName || !mobileNumber || !email || !password) {
      return res.status(400).json({ error: 'Missing required fields.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const consentRecords = (consents || []).map((c) => ({
      type: c.type,
      version: c.version || '1.0',
      acceptedAt: new Date(),
      ipAddress: req.ip,
    }));

    const customer = await Customer.create({
      fullName,
      mobileNumber,
      email,
      passwordHash,
      mobileVerified: true, // assumes OTP step already completed client-side
      consents: consentRecords,
    });

    await recordAuditEvent({
      actorId: customer._id,
      actorType: 'customer',
      action: 'CUSTOMER_REGISTERED',
      targetId: customer._id,
      metadata: { mobileNumber },
    });

    res.status(201).json({ id: customer._id, fullName: customer.fullName });
  } catch (err) {
    res.status(500).json({ error: 'Registration failed.' });
  }
}

async function login(req, res) {
  try {
    const { email, password } = req.body;
    const customer = await Customer.findOne({ email });
    if (!customer) return res.status(401).json({ error: 'Invalid email or password.' });

    const valid = await bcrypt.compare(password, customer.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Invalid email or password.' });

    const token = jwt.sign(
      { id: customer._id, role: 'customer' },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '1h' }
    );

    customer.lastLoginAt = new Date();
    await customer.save();

    res.json({ token, expiresIn: process.env.JWT_EXPIRES_IN || '1h' });
  } catch (err) {
    res.status(500).json({ error: 'Login failed.' });
  }
}

async function logout(req, res) {
  // With stateless JWTs, logout is handled client-side by discarding the token.
  // For stronger session control, maintain a token blocklist or use short-lived
  // access tokens with refresh tokens stored server-side.
  res.json({ message: 'Logged out.' });
}

module.exports = { register, sendOtp, verifyOtp, login, logout };
