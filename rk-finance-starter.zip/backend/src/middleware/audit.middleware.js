// RBI compliance requires an audit trail for administrative actions and
// timestamped records of customer consent. This is a minimal starting point -
// in production, write audit entries to an append-only store (e.g. a
// dedicated AuditLog collection or a write-once log service).

function auditLogger(req, res, next) {
  req.auditContext = {
    requestId: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    timestamp: new Date().toISOString(),
    ip: req.ip,
    method: req.method,
    path: req.originalUrl,
  };
  next();
}

// Call this from controllers whenever a customer accepts a consent,
// agreement, or KFS, or when an admin performs a sensitive action.
async function recordAuditEvent({ actorId, actorType, action, targetId, metadata = {} }) {
  const AuditLog = require('../models/AuditLog.model');
  return AuditLog.create({
    actorId,
    actorType, // 'customer' | 'admin' | 'system'
    action, // e.g. 'CONSENT_ACCEPTED', 'LOAN_RATE_UPDATED', 'DOCUMENT_VERIFIED'
    targetId,
    metadata,
    timestamp: new Date(),
  });
}

module.exports = { auditLogger, recordAuditEvent };
