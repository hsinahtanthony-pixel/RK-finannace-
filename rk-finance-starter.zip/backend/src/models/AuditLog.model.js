const mongoose = require('mongoose');

// Append-only by convention: only ever insert, never update or delete
// entries here. Consider a separate database/collection with restricted
// write permissions in production, per RBI's audit trail expectations.
const auditLogSchema = new mongoose.Schema({
  actorId: { type: mongoose.Schema.Types.Mixed },
  actorType: { type: String, enum: ['customer', 'admin', 'system'], required: true },
  action: { type: String, required: true },
  targetId: { type: mongoose.Schema.Types.Mixed },
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
  timestamp: { type: Date, required: true, default: Date.now },
});

module.exports = mongoose.model('AuditLog', auditLogSchema);
