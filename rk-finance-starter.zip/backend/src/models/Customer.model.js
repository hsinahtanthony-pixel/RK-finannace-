const mongoose = require('mongoose');

const consentRecordSchema = new mongoose.Schema({
  type: { type: String, required: true }, // 'PRIVACY_POLICY' | 'TERMS' | 'KFS' | 'DATA_COLLECTION'
  version: { type: String, required: true },
  acceptedAt: { type: Date, required: true },
  ipAddress: String,
}, { _id: false });

const customerSchema = new mongoose.Schema({
  fullName: { type: String, required: true },
  mobileNumber: { type: String, required: true, unique: true },
  mobileVerified: { type: Boolean, default: false },
  email: { type: String, required: true, unique: true },
  emailVerified: { type: Boolean, default: false },
  passwordHash: { type: String, required: true },
  twoFactorEnabled: { type: Boolean, default: false },

  // Store only references/hashes to KYC documents, never raw numbers, in plaintext.
  // Actual documents belong in encrypted object storage (see DOCUMENT_STORAGE_BUCKET),
  // with only a pointer/reference kept here.
  kyc: {
    panRef: String,
    aadhaarRef: String, // optional, where legally permitted
    passportRef: String,
    drivingLicenceRef: String,
    voterIdRef: String,
    verificationStatus: { type: String, enum: ['pending', 'verified', 'rejected'], default: 'pending' },
    verificationProvider: String, // approved e-KYC/CKYC provider name
  },

  address: {
    line1: String,
    line2: String,
    city: String,
    state: String,
    pincode: String,
  },

  occupation: String,
  employer: String,
  monthlyIncome: Number,

  bankDetails: {
    accountNumberRef: String, // reference/token, not raw account number
    ifsc: String,
    bankName: String,
  },

  consents: [consentRecordSchema],

  role: { type: String, enum: ['customer'], default: 'customer' },
  lastLoginAt: Date,
}, { timestamps: true });

module.exports = mongoose.model('Customer', customerSchema);
