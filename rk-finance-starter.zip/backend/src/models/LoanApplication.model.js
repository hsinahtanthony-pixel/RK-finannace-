const mongoose = require('mongoose');

const loanApplicationSchema = new mongoose.Schema({
  customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
  loanProduct: { type: mongoose.Schema.Types.ObjectId, ref: 'LoanProduct', required: true },
  loanAmountRequested: { type: Number, required: true },
  loanPurpose: String,
  tenureMonthsRequested: Number,

  status: {
    type: String,
    enum: ['submitted', 'under_review', 'kfs_issued', 'approved', 'rejected', 'disbursed', 'closed'],
    default: 'submitted',
  },

  documents: [{
    type: { type: String }, // 'pan' | 'aadhaar' | 'income_proof' | 'bank_statement' | ...
    storageRef: String, // pointer to encrypted object storage, not raw file
    verifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'AdminUser' },
    verifiedAt: Date,
  }],

  keyFactStatement: {
    issuedAt: Date,
    interestRateAnnualPct: Number,
    apr: Number,
    processingFee: Number,
    totalRepayment: Number,
    documentRef: String, // pointer to the generated KFS PDF
  },

  consentTimestamp: Date, // when the customer accepted the loan agreement
  emiSchedule: [{
    month: Number,
    emi: Number,
    interestPortion: Number,
    principalPortion: Number,
    balance: Number,
    paidAt: Date,
    status: { type: String, enum: ['upcoming', 'paid', 'overdue'], default: 'upcoming' },
  }],
}, { timestamps: true });

module.exports = mongoose.model('LoanApplication', loanApplicationSchema);
