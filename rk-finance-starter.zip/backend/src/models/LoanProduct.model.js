const mongoose = require('mongoose');

const loanProductSchema = new mongoose.Schema({
  slug: { type: String, required: true, unique: true }, // 'personal', 'business', 'gold', 'vehicle', 'home', 'education'
  name: { type: String, required: true },
  interestRateAnnualPct: { type: Number, required: true }, // admin-editable
  processingFeeFlat: { type: Number, default: 0 },
  processingFeePct: { type: Number, default: 0 },
  penaltyChargePct: { type: Number, default: 0 },
  minTenureMonths: { type: Number, required: true },
  maxTenureMonths: { type: Number, required: true },
  minAmount: { type: Number, required: true },
  maxAmount: { type: Number, required: true },
  eligibilityCriteria: [String],
  requiredDocuments: [String],
  representativeExample: {
    amount: Number,
    tenureMonths: Number,
    apr: Number,
  },
  termsAndConditionsUrl: String,
  isActive: { type: Boolean, default: true },
  lastEditedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'AdminUser' },
}, { timestamps: true });

module.exports = mongoose.model('LoanProduct', loanProductSchema);
