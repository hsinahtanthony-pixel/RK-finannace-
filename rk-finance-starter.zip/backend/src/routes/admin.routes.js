const express = require('express');
const router = express.Router();
const { requireAuth, requireRole } = require('../middleware/auth.middleware');
const LoanProduct = require('../models/LoanProduct.model');
const LoanApplication = require('../models/LoanApplication.model');
const AuditLog = require('../models/AuditLog.model');
const { recordAuditEvent } = require('../middleware/audit.middleware');

router.use(requireAuth, requireRole('admin', 'compliance_officer'));

// Interest rate / fee management - every change is audit-logged
router.put('/loans/:id', async (req, res) => {
  const updates = req.body;
  const loan = await LoanProduct.findByIdAndUpdate(req.params.id, {
    ...updates,
    lastEditedBy: req.user.id,
  }, { new: true });

  await recordAuditEvent({
    actorId: req.user.id,
    actorType: 'admin',
    action: 'LOAN_RATE_UPDATED',
    targetId: loan._id,
    metadata: updates,
  });

  res.json(loan);
});

router.get('/applications', async (req, res) => {
  const applications = await LoanApplication.find().populate('customer loanProduct');
  res.json(applications);
});

router.put('/applications/:id/status', async (req, res) => {
  const { status } = req.body;
  const application = await LoanApplication.findByIdAndUpdate(req.params.id, { status }, { new: true });

  await recordAuditEvent({
    actorId: req.user.id,
    actorType: 'admin',
    action: 'APPLICATION_STATUS_CHANGED',
    targetId: application._id,
    metadata: { status },
  });

  res.json(application);
});

router.get('/audit-logs', async (req, res) => {
  const logs = await AuditLog.find().sort({ timestamp: -1 }).limit(500);
  res.json(logs);
});

module.exports = router;
