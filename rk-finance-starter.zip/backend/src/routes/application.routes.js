const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth.middleware');
const applicationController = require('../controllers/application.controller');

router.use(requireAuth);

router.post('/', applicationController.createApplication);
router.get('/', applicationController.listMyApplications);
router.get('/:id', applicationController.getApplication);
router.post('/:id/documents', applicationController.attachDocument);
router.post('/:id/consent', applicationController.recordConsent);

module.exports = router;
