const express = require('express');
const router = express.Router();

// Serves the statutory disclosure details for the RBI Compliance & Disclosures page.
// These values come from environment variables so the business owner can fill
// them in once real registration is confirmed, without touching code.
router.get('/disclosures', (req, res) => {
  res.json({
    rbiRegistrationNumber: process.env.COMPANY_RBI_REGISTRATION_NO || null,
    cin: process.env.COMPANY_CIN || null,
    gstin: process.env.COMPANY_GSTIN || null,
    isRegistrationConfirmed: Boolean(process.env.COMPANY_RBI_REGISTRATION_NO),
    grievanceOfficer: {
      name: process.env.GRIEVANCE_OFFICER_NAME || null,
      email: process.env.GRIEVANCE_OFFICER_EMAIL || null,
      escalationDays: 30,
    },
  });
});

module.exports = router;
