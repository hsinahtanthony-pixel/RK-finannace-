const express = require('express');
const router = express.Router();
const { calculateEmi } = require('../utils/emi.util');

// POST /api/emi/calculate  { principal, annualRatePct, tenureMonths }
router.post('/calculate', (req, res) => {
  const { principal, annualRatePct, tenureMonths } = req.body;

  if (!principal || !annualRatePct || !tenureMonths) {
    return res.status(400).json({ error: 'principal, annualRatePct and tenureMonths are required.' });
  }

  const result = calculateEmi({ principal, annualRatePct, tenureMonths });
  res.json(result);
});

module.exports = router;
