const express = require('express');
const router = express.Router();
const LoanProduct = require('../models/LoanProduct.model');

// Public: list active loan products
router.get('/', async (req, res) => {
  const loans = await LoanProduct.find({ isActive: true });
  res.json(loans);
});

// Public: single loan product detail
router.get('/:slug', async (req, res) => {
  const loan = await LoanProduct.findOne({ slug: req.params.slug, isActive: true });
  if (!loan) return res.status(404).json({ error: 'Loan product not found.' });
  res.json(loan);
});

module.exports = router;
