require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const mongoose = require('mongoose');

const authRoutes = require('./routes/auth.routes');
const loanRoutes = require('./routes/loan.routes');
const applicationRoutes = require('./routes/application.routes');
const emiRoutes = require('./routes/emi.routes');
const adminRoutes = require('./routes/admin.routes');
const complianceRoutes = require('./routes/compliance.routes');
const { auditLogger } = require('./middleware/audit.middleware');

const app = express();

// Security middleware - see RBI Compliance section in README
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '2mb' }));
app.use(morgan('combined'));
app.use(auditLogger);

// Basic rate limiting - tune per endpoint sensitivity (e.g. login/OTP stricter)
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 300 }));

app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', authRoutes);
app.use('/api/loans', loanRoutes);
app.use('/api/applications', applicationRoutes);
app.use('/api/emi', emiRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/compliance', complianceRoutes);

// Central error handler - never leak stack traces in production
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' ? 'Something went wrong.' : err.message,
  });
});

const PORT = process.env.PORT || 4000;

async function start() {
  try {
    if (process.env.MONGO_URI) {
      await mongoose.connect(process.env.MONGO_URI);
      console.log('Connected to MongoDB');
    } else {
      console.warn('MONGO_URI not set - starting without a database connection.');
    }
    app.listen(PORT, () => console.log(`RK Finance API listening on port ${PORT}`));
  } catch (err) {
    console.error('Failed to start server:', err.message);
    process.exit(1);
  }
}

start();

module.exports = app;
