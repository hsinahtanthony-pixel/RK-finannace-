// Standard reducing-balance EMI calculation.
// EMI = P * r * (1+r)^n / ((1+r)^n - 1), where r is the monthly rate.
function calculateEmi({ principal, annualRatePct, tenureMonths }) {
  const monthlyRate = annualRatePct / 12 / 100;
  const factor = Math.pow(1 + monthlyRate, tenureMonths);
  const emi = (principal * monthlyRate * factor) / (factor - 1);

  let balance = principal;
  const schedule = [];
  for (let month = 1; month <= tenureMonths; month++) {
    const interestPortion = balance * monthlyRate;
    const principalPortion = emi - interestPortion;
    balance = Math.max(balance - principalPortion, 0);
    schedule.push({
      month,
      emi: round2(emi),
      interestPortion: round2(interestPortion),
      principalPortion: round2(principalPortion),
      balance: round2(balance),
    });
  }

  const totalRepayment = emi * tenureMonths;
  const totalInterest = totalRepayment - principal;

  return {
    emi: round2(emi),
    totalInterest: round2(totalInterest),
    totalRepayment: round2(totalRepayment),
    schedule,
  };
}

function round2(n) {
  return Math.round(n * 100) / 100;
}

module.exports = { calculateEmi };
