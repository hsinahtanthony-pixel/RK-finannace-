import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import LoanProducts from './pages/LoanProducts';
import LoanDetail from './pages/LoanDetail';
import Calculator from './pages/Calculator';
import Apply from './pages/Apply';
import Login from './pages/Login';
import Compliance from './pages/Compliance';

// Add auth-gated routes (Dashboard, EMI schedule, document downloads) once
// the login flow is wired to the backend's /api/auth endpoints.
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/loans" element={<LoanProducts />} />
        <Route path="/loans/:slug" element={<LoanDetail />} />
        <Route path="/calculator" element={<Calculator />} />
        <Route path="/apply" element={<Apply />} />
        <Route path="/login" element={<Login />} />
        <Route path="/compliance" element={<Compliance />} />
      </Routes>
    </BrowserRouter>
  );
}
