import { useState, useEffect, useMemo } from 'react';
import apiClient from '../utils/apiClient';

// Mirrors the reducing-balance calculation in backend/src/utils/emi.util.js
// so the UI can update instantly, then reconciles with the server on submit
// for the authoritative figure shown in the Key Fact Statement.
function calculateEmiLocally(principal, annualRatePct, tenureMonths) {
  const monthlyRate = annualRatePct / 12 / 100;
  const factor = Math.pow(1 + monthlyRate, tenureMonths);
  const emi = (principal * monthlyRate * factor) / (factor - 1);
  const totalRepayment = emi * tenureMonths;
  return {
    emi: Math.round(emi),
    totalInterest: Math.round(totalRepayment - principal),
    totalRepayment: Math.round(totalRepayment),
  };
}

export default function EmiCalculator({ defaultRate = 13.5 }) {
  const [amount, setAmount] = useState(500000);
  const [rate, setRate] = useState(defaultRate);
  const [tenure, setTenure] = useState(36);

  const result = useMemo(() => calculateEmiLocally(amount, rate, tenure), [amount, rate, tenure]);

  const formatInr = (n) => `₹${n.toLocaleString('en-IN')}`;

  return (
    <div className="rounded border border-slate-200 bg-white p-6">
      <label className="block text-sm text-slate-600 mb-1">
        Loan amount: <span className="font-mono">{formatInr(amount)}</span>
      </label>
      <input
        type="range" min={10000} max={5000000} step={10000}
        value={amount} onChange={(e) => setAmount(Number(e.target.value))}
        className="w-full mb-4"
      />

      <label className="block text-sm text-slate-600 mb-1">
        Interest rate: <span className="font-mono">{rate.toFixed(1)}%</span>
      </label>
      <input
        type="range" min={8} max={28} step={0.1}
        value={rate} onChange={(e) => setRate(Number(e.target.value))}
        className="w-full mb-4"
      />

      <label className="block text-sm text-slate-600 mb-1">
        Tenure: <span className="font-mono">{tenure} months</span>
      </label>
      <input
        type="range" min={3} max={84} step={1}
        value={tenure} onChange={(e) => setTenure(Number(e.target.value))}
        className="w-full mb-6"
      />

      <div className="border-t border-dashed border-slate-200 pt-4 space-y-2 font-mono text-sm">
        <div className="flex justify-between"><span className="text-slate-500">Monthly EMI</span><span>{formatInr(result.emi)}</span></div>
        <div className="flex justify-between"><span className="text-slate-500">Total interest</span><span>{formatInr(result.totalInterest)}</span></div>
        <div className="flex justify-between font-semibold"><span>Total repayment</span><span>{formatInr(result.totalRepayment)}</span></div>
      </div>

      <p className="text-xs text-slate-500 mt-4">
        Illustrative only. Final figures are confirmed in your Key Fact Statement before loan acceptance.
      </p>
    </div>
  );
}
