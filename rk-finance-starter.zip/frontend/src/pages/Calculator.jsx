// Placeholder page - port the corresponding section from
// rk-finance-prototype.html into this component, wiring data through
// src/utils/apiClient.js instead of the hardcoded arrays used in the prototype.
export default function Calculator() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <h1 className="text-2xl font-semibold">Calculator</h1>
      <p className="text-slate-500 mt-2">Build this page from the matching section of rk-finance-prototype.html.</p>
    </div>
  );
}
