import axios from 'axios';

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000/api',
});

// Attach the JWT to every request once the user has logged in.
apiClient.interceptors.request.use((config) => {
  const token = sessionStorage.getItem('rk_finance_token');
  // Note: sessionStorage clears on tab close, giving a simple form of
  // automatic logout. For production, also enforce token expiry server-side
  // and consider an idle-timeout that calls /auth/logout.
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default apiClient;
